const assert      	= require('chai').assert;			/*To test*/
const scraper    	= require('../scraperScript.js');   /*To import the testing scripts*/
const fs 			= require('fs');					/*To read the html file, Filesystemojbect*/
const jsdom         = require("jsdom");             	/*To conver the recieved html to DOM*/
const { JSDOM }     = jsdom;                        	/*To conver the recieved html to DOM*/
const jsonfile      = require('jsonfile');          	/*To write out the created object into a seperate jsonfile*/

// Creating a virtual DOM document for testing purposes
const htmlBody 		= fs.readFileSync('./sampleDomHtml.html', 'utf8');
const dom 			= new JSDOM(htmlBody);
const vdom 			= dom.window.document;
const url			= 'https://www.stackoverflow.com';

describe('Scraper', function(){
	it('the depth should be bigger than 1',function(){
		let result = scraper.scrapeDepth(vdom);
		assert.isAbove(result,1 );

	});
	it('the result should be an object',function(){
		let result = scraper.childElements(Array.from(vdom.getElementsByTagName("*")));
		assert.typeOf(result, 'object', 'we have an ojbect');

	});
    it('the result should be an object',function(){
		let result = scraper.scrapStart(htmlBody,url);
		assert.typeOf(result, 'object', 'we have an object');

	});


});